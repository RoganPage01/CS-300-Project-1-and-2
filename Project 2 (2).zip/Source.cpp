#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm> // for sorting

using namespace std;

// Define a structure to hold course information
struct Course {
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;
};

// Function prototypes
void loadDataStructure(vector<Course>& courses, const string& filename);
void printCourseList(const vector<Course>& courses);
void printCourse(const vector<Course>& courses, const string& courseNumber);

int main() {
    vector<Course> courses; // Data structure to hold courses

    char choice;
    string filename;
    string courseNumber; // Initialize courseNumber here

    do {
        // Display menu
        cout << "\nMENU:\n";
        cout << "1. Load Data Structure\n";
        cout << "2. Print Course List\n";
        cout << "3. Print Course\n";
        cout << "4. Exit\n";                                                                                                                                                                                                                                                                                                                                                                                                                                      
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case '1':
            cout << "Enter filename: ";
            cin >> filename;
            loadDataStructure(courses, filename);
            break;
        case '2':
            printCourseList(courses);
            break;
        case '3':
            cout << "Enter course number: ";
            cin >> courseNumber; // Initialize courseNumber here
            printCourse(courses, courseNumber);
            break;
        case '4':
            cout << "Exiting program.\n";
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
        }

    } while (choice != '4');

    return 0;
}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
void loadDataStructure(vector<Course>& courses, const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error: Unable to open file.\n";
        return;
    }

    // Clear previous data
    courses.clear();

    string line;
    while (getline(file, line)) {
        // Assuming each line contains course data in the format: courseNumber,courseTitle,prerequisite1,prerequisite2,...
        Course course;
        size_t pos = 0;
        pos = line.find(",");
        course.courseNumber = line.substr(0, pos);
        line.erase(0, pos + 1);
        pos = line.find(",");
        course.courseTitle = line.substr(0, pos);
        line.erase(0, pos + 1);
        while ((pos = line.find(",")) != string::npos) {
            course.prerequisites.push_back(line.substr(0, pos));
            line.erase(0, pos + 1);
        }
        // Add course to the vector
        courses.push_back(course);
    }

    file.close();
    cout << "Data loaded successfully.\n";
}

void printCourseList(const vector<Course>& courses) {
    if (courses.empty()) {
        cout << "No data available. Please load data first.\n";
        return;
    }

    // Sort courses by course number
    vector<Course> sortedCourses = courses;
    sort(sortedCourses.begin(), sortedCourses.end(), [](const Course& a, const Course& b) {
        return a.courseNumber < b.courseNumber;
        });

    // Print sorted course list
    cout << "Course List:\n";
    for (const auto& course : sortedCourses) {
        cout << course.courseNumber << " - " << course.courseTitle << endl;
    }
}

void printCourse(const vector<Course>& courses, const string& courseNumber) {
    if (courses.empty()) {
        cout << "No data available. Please load data first.\n";
        return;
    }

    // Search for the course
    for (const auto& course : courses) {
        if (course.courseNumber == courseNumber) {
            // Print course information
            cout << "Course Title: " << course.courseTitle << endl;
            cout << "Prerequisites:\n";
            for (const auto& prerequisite : course.prerequisites) {
                cout << prerequisite << endl;
            }
            return;
        }
    }

    // If course is not found
    cout << "Course not found.\n";
}
